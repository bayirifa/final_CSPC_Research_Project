# Benjamin Ayirifa
# Lewis University
# Research project, Fall semester, 2023

# import
import os
import sys

# path
positive_folder = 'C:/Users/owner/Desktop/control/positives'

# define variables
count_pattern = 0  # count the number of design pattern detected by the tool
total_files = 0   # count the number files parsed by the module
# patternID is used to check for pattern based on unique identifiers
patternID = {
    "Creator": "Factory Method",
    "Prototype": "Prototype",
    "Adapter": "Adapter",
    "Decorator": "Decorator",
    "Observer": "Observer",
    "State": "State",
    "Singleton": "Singleton",
    "Strategy": "Strategy",
    "Implementor": "Bridge",
    "AbstractClass": "Template",
    "Visitor": "Visitor",
    "Proxy": "Proxy",
    "Handler": "Chain of Responsibilities",
    "ConcreteCommand": "Command",
    "Composite": "Composite"
}
pattern_count = {}  # this dictionary stores the number of times a design pattern is detected and records it

for file in os.listdir(positive_folder):
    total_files += 1
    for i in patternID:
        xml_file = os.path.join(positive_folder, file)
        with open(xml_file, 'r') as rd:
            data = rd.readlines()
            for pattern in data:
                if f'<role name="{i}"' in pattern:
                    count_pattern += 1
                    if i in pattern_count:
                        pattern_count[i] = pattern_count[i] + 1
                    else:
                        pattern_count[i] = 1
print("Total instance detected in all the projects are ", count_pattern, f'all the {total_files} projects examined\n')
check_total = 0
for d in pattern_count:
    print(f'{d}: {pattern_count[d]}')
    check_total = check_total + pattern_count[d]
print(check_total)
# close program module
sys.exit(0)
