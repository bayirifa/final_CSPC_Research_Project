# Benjamin Ayirifa
# Lewis University
# Fall semester 2023
# Research Project

# imports
import os
import shutil

# variables
xml_folder = 'C:/Users/owner/Desktop/control/results_cases'
positive_folder = 'C:/Users/owner/Desktop/control/positives'
count_pattern = 0
count_files = 0
for file in os.listdir(xml_folder):
    xml_file = os.path.join(xml_folder, file)
    count_files += 1
    with open(xml_file, 'r') as rd:
        data = rd.read()
        if '<instance>' in data:
            # counts the number of projects that are positive for atleast one pattern
            count_pattern += 1
            # makes a copy of the positive file into the positive folder
            shutil.copy(xml_file, positive_folder)
            # print the file on terminal
            print(xml_file)
    rd.close()
# print total over total xml_files counted
print(f'The total number of projects with design pattern is {count_pattern}/{count_files}')
