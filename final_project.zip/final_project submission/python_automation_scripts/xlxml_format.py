# Benjamin Ayirifa
# Lewis University
# Fall semester 2023
# Research Project
'''This program reads excel file for repository links to the positive cases'''
# imports
import os
from openpyxl.workbook import Workbook
from openpyxl import load_workbook
import sys
# variable
excel_repo = 'C:/Users/owner/Desktop/project analysis/repository/Book1.xlsx'
positive_folder = 'C:/Users/owner/Desktop/control/positives'
to_write = 'C:/Users/owner/Desktop/project analysis/repository/positive_links.xlsx'

# define spec
load_file = load_workbook(excel_repo)
write_excel = load_workbook(to_write)
current_sheet = load_file.active


# loop through positive files
for item in os.listdir(positive_folder):
    tup_item = os.path.splitext(item)
    cell = "A" + tup_item[0]
    print(f'{tup_item[0]} : {current_sheet[cell].value}')
sys.exit(0)
