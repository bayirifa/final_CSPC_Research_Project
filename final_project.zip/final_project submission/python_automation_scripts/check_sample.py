# Benjamin Ayirifa
# Lewis University
# Research project, Fall semester

# import
import sys

from aspose.cells import Workbook
import os
import logging

# variables
files = 'C:/Users/owner/Desktop/cases'
results = 'C:/Users/owner/Desktop/control/results_cases'
exemption_log = 'C:/Users/owner/Desktop/logfile/exemption.log'
count = 0
folders_item = []
logging.basicConfig(filename=exemption_log, level=logging.INFO)


# loop files
for file in os.listdir(results):
    string_list = os.path.splitext(file)
    folders_item.append(int(string_list[0]))

real = folders_item

for item in os.listdir(files):
    if int(item) not in real:
        print(item)
        count = count + 1
        logging.info(f'{item}')
print(f'count: {count}')
logging.info(f'Total projects that failed due to illegal exemption: {count}')
sys.exit()
