# Benjamin Ayirifa
# Lewis University
# Research project, Fall semester, 2023

# import
import os
import sys

# path
positive_folder = 'C:/Users/owner/Desktop/control/positives'

# variables
count_factory = 0
count_prototype = 0
count_adapter = 0
count_decorator = 0
count_observer = 0
count_state = 0
count_singleton = 0
count_command = 0
count_strategy = 0
count_bridge = 0
count_template = 0
count_visitor = 0
count_proxy = 0
count_chain = 0
count_composite = 0

count_files = 0
count_patterns = 0
# parse multiple files
for file in os.listdir(positive_folder):
    xml_file = os.path.join(positive_folder, file)
    count_files += 1
    with open(xml_file, 'r') as rd:
        data = rd.readlines()
        for pattern in data:
            if '<instance>' in pattern:
                count_patterns += 1
            if '<role name="Creator"' in pattern:
                count_factory += 1
            if '<role name="Prototype"' in pattern:
                count_prototype += 1
            if '<role name="Adapter"' in pattern:
                count_adapter += 1
            if '<role name="Decorator"' in pattern:
                count_decorator += 1
            if '<role name="Observer"' in pattern:
                count_observer += 1
            if '<role name="State"' in pattern:
                count_state += 1
            if '<role name="Singleton"' in pattern:
                count_singleton += 1
            if '<role name="Strategy"' in pattern:
                count_strategy += 1
            if '<role name="Implementor"' in pattern:
                count_bridge += 1
            if '<role name="AbstractClass"' in pattern:
                count_template += 1
            if '<role name="Visitor"' in pattern:
                count_visitor += 1
            if '<role name="Proxy"' in pattern:
                count_proxy += 1
            if '<role name="Handler"' in pattern:
                count_chain += 1
            if '<role name="ConcreteCommand"' in pattern:
                count_command += 1
                # print(pattern, xml_file)
            if '<role name="Composite"' in pattern:
                count_composite += 1
                # print(pattern, xml_file) # use this print to check places and projects it's implemented
    rd.close()
total = count_factory+ count_prototype+ count_adapter + count_decorator + count_observer +\
        count_state + count_singleton + count_command + count_strategy + count_bridge + \
        count_template + count_visitor + count_proxy + count_chain + count_composite
print(f'Factory Method : {count_factory}')
print(f'Prototype      : {count_prototype}')
print(f'Adapter        : {count_adapter}')
print(f'Decorator      : {count_decorator}')
print(f'Observer       : {count_observer}')
print(f'State          : {count_state}')
print(f'Singleton      : {count_singleton}')
print(f'Strategy       : {count_strategy}')
print(f'Bridge         : {count_bridge}')
print(f'Template       : {count_template}')
print(f'Visitor        : {count_visitor}')
print(f'Proxy          : {count_proxy}')
print(f'Command        : {count_command}')
print(f'Chain of Responsibility : {count_chain}')
print(f'Composite      : {count_composite}')
print('Total of all design pattern detected: ', total)
print('All <instance> counted: ', count_patterns)
print('Total files opened and  checked :', count_files)
sys.exit(0)
