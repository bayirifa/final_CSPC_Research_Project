# Benjamin Ayirifa
# Lewis University
# Fall semester 2023
# Research Project
'''I used this module to double check patterns to test algorithm,
    all files are supposed to be positive (100%) for a pattern'''
# imports
import os
import logging
import sys

# variables
positive_folder = 'C:/Users/owner/Desktop/control/positives'
count_pattern = 0
count_files = 0
pattern_per_project = 0

# determine log file to store events
positive_log = 'C:/Users/owner/Desktop/logfile/pattern_per_positive.log'
logging.basicConfig(filename=positive_log, level=logging.INFO)

# iterate all positive xml files
for file in os.listdir(positive_folder):
    xml_file = os.path.join(positive_folder, file)
    count_files += 1
    with open(xml_file, 'r') as rd:
        data = rd.readlines()
        for pattern in data:
            if '<instance>' in pattern:
                # print(pattern)
                pattern_per_project += 1
                count_pattern += 1
        print(f'{xml_file} has a total number of {pattern_per_project}')
        logging.info(f'{xml_file} has a total number of {pattern_per_project}')
        pattern_per_project = 0
    rd.close()
# print total over total xml_files counted
print(f'The total number of projects with design pattern is {count_pattern} in all the {count_files} projects')
logging.info(f'The total number of projects with design pattern is {count_pattern} in all the {count_files} projects')
sys.exit()
