# Benjamin Ayirifa
# Lewis University
# Research project, Fall semester'
'''This module was used to automate the cloning of the repository urls stored
    as a text file'''

# imports
import sys
from git import Repo, remove_password_if_present, GitCommandError
import os

# variables
# text file holding repos
path_file = 'C:/Users/owner/Desktop/project analysis/repository/myoriginal_links.txt'
# repo depot
dir_repo_path = 'C:/Users/owner/Desktop/project analysis/all repository'
# count the number of repos cloned as count
count = 1
# read text file containing repo links
with open(path_file, 'r') as lk:
    for row in lk:
        # strip off whitespaces
        link_repo = row.strip() + ".git"
        # print to show the link being accessed
        print(count, link_repo)
        print("project cloning...")
        dir_for_new_repo = os.path.join(dir_repo_path, str(count))
        # try -catch approach to clone projects
        try:
            print(f'Creating directory for {link_repo}')
            os.mkdir(dir_for_new_repo)
            Repo.clone_from(link_repo, dir_for_new_repo)
            print(f'Folder {count} created and project cloned successfully')
        except (GitCommandError, OSError, PermissionError, Exception) as error:
            print(f'There was a problem creating the folder {link_repo}\n')
            print(error)
            # remove folder which was created
            os.rmdir(dir_for_new_repo)

        # count increment
        count += 1
lk.close()
sys.exit()
