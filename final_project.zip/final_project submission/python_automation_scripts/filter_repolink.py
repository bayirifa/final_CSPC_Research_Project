# Benjamin Ayirifa
# Lewis University
# Research project, Fall semester

# import
from aspose.cells import Workbook
import os

# variables
project_src = 'C:/Users/owner/Desktop/cases'
text_repo = open('C:/Users/owner/Desktop/project analysis/repository/myoriginal_links.txt', "r")
sorted_link = open('C:/Users/owner/Desktop/control/sorted_links.txt', 'w')
cloned_array = []
count_project = 0

# reverse checking to prove all end files a re subsets of the main files
for project in os.listdir(project_src):
    # print(project)
    cloned_array.append(int(project))
    count_project += 1
print(count_project)
print(cloned_array)
to_check = cloned_array
x=0
check_link_count = 0
for link in text_repo:
    print(link)
    x +=1
    if x in cloned_array:
        sorted_link.write(link)
        check_link_count += 1
print(check_link_count)
print(x)
sorted_link.close()
text_repo.close()
