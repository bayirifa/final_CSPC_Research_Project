# Benjamin Ayirifa
# Lewis University
# Research project, Fall semester
'''This module converts the xml to txt file so I can read each line since I cannot
    read each line in xml. I visually checked some of the files and noted some have
    multiple patterns per project so I want to know the number of patterns per project'''
# import
import sys
from aspose.cells import Workbook
import os

# variables
positive_folder = 'C:/Users/owner/Desktop/control/positives'
text_location = 'C:/Users/owner/Desktop/control/xml_text'

# iterate and convert to text file
for items in os.listdir(positive_folder):
    # split to get the unique ID number
    stub = os.path.splitext(items)
    try:
        workbook = Workbook(os.path.join(positive_folder, items))
        workbook.save(os.path.join(text_location, (stub[0]+'.txt')))
    except (OSError, FileExistsError) as error:
        print(error)
        pass
sys.exit()
