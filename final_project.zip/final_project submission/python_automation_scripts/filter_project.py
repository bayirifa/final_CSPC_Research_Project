# Benjamin Ayirifa
# Lewis University
# Research project, Fall semester'
'''This program checks through all the cloned projects for ones that can be
    maven; Maven requires pom.xml file in every project to start cloning hence
    I checked for the file path of pom file in each cloned project;
    all project with out pom file were filtered into another folder'''
# import
import os
import shutil
import logging
import sys

# variables
sample_path = 'C:/Users/owner/Desktop/project analysis/all repository'
bin_path = 'C:/Users/owner/Desktop/project analysis/further'
to_delete = 'C:/Users/owner/Desktop/logfile/app.log'
logging.basicConfig(filename=to_delete, level=logging.DEBUG)
count_moved = 0
count_pom = 0

# check folder for projects built with mvn using the pom.xml as reference
for items in os.listdir(sample_path):
    dir_check = (os.path.join(sample_path, items))
    file_check = os.path.join(dir_check, 'pom.xml')
    # checks for pom.xml file in each project
    if os.path.exists(file_check):
        count_pom += 1
        # if it exists, then it is ok to pass
        pass
    else:
        # move folder from current location to another place for further consideration
        # and log event to file
        logging.info(f'{items}, needs consideration')
        shutil.move(dir_check, bin_path)
        # print on terminal when moved
        print(dir_check, 'is moved')
        count_moved += 1
print(f'moved folders are {count_moved} with {count_pom} left')
# end module
sys.exit()
