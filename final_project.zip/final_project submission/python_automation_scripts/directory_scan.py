# Benjamin Ayirifa
# Lewis University
# Research project, Fall semester'

# import
import os

# variable for dir
sample_path = 'C:/Users/owner/Desktop/project analysis/all repository'

# check for empty project folders
# use this module multiple times to remove empty folders
for items in os.listdir(sample_path):
    dirs_check = os.path.join(sample_path, items)
    if len(os.listdir(dirs_check)) <= 2:
        os.rmdir(dirs_check)
