# Benjamin Ayirifa
# Lewis University
# Research project, Fall semester

# import
import os

# variables
text_repo = open('C:/Users/owner/Desktop/project analysis/repository/original_links.txt', "r")
check_repo = open('C:/Users/owner/Desktop/project analysis/repository/myoriginal_links.txt', "w")
check_array = []
# iterate over item
for item in text_repo:
    item = item.strip()
    print(item)
    if item in check_array:
        pass
    else:
        check_array.append(item)

with check_repo as ck:
    for url in check_array:
        ck.write(url)
