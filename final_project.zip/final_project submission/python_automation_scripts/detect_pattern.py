# Benjamin Ayirifa
# Lewis University
# Research project, Fall semester'

''' this program auto detects pattern and generate xml file'''
# import
import os
import logging
import sys
import time
# variables definition
sample_src = 'C:/Users/owner/Desktop/special'
result_folder = 'C:/Users/owner/Desktop/control/results_cases'
records = 'C:/Users/owner/Desktop/logfile'
log_file = os.path.join(records, 'result_log.log')
logging.basicConfig(filename=log_file, level=logging.DEBUG)
# count errors with tools
count_error = 0
# item the folder and pass the command to the correct path
for item in os.listdir(sample_src):
    target_src = os.path.join(sample_src, item)
    result_file = os.path.join(result_folder, item) + '.xml'
    # checks for errors in tool execution, prints and writes to log file
    try:
        cmd_command = f'java -Xms32m -Xmx512m -jar pattern4.jar -target "{target_src}" -output "{result_file}"'
        os.system(cmd_command)
        logging.info(f'{time.asctime()}, {target_src}, had a generated report at {result_file}')
    # catches any other error and logs it to file
    except (OSError, Exception) as error:
        count_error += 1
        logging.error(f'{time.asctime()}, {target_src} had error \n {error}')
        logging.exception(f'{error}')
        print(error)
        pass
# print # total number of tool exemptions
print(f'{count_error} projects had an error with the pattern tool')
sys.exit()
