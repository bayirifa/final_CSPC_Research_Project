# Benjamin Ayirifa
# Lewis University
# Research project, Fall semester'
'''This module is used to organized .class files in each project'''
# import modules
import logging
import os
import shutil
import time

# variables
bin_source = 'C:/Users/owner/Desktop/cases/1000_1500'
log_file = 'C:/Users/owner/Desktop/logfile/search_log.log'
sample_loc = 'C:/Users/owner/Desktop/project analysis/further'

'''This module is used to parse the files in cloned project to 
to organize bin/.class sources of the project into another folder 
to be detected by the tool'''
# file log to keep all actions
logging.basicConfig(filename=log_file, level=logging.DEBUG)

# search loop
for items in os.listdir(sample_loc):
    current_dir = os.path.join(sample_loc, items)
    # print(current_dir)
    bin_source2 = os.path.join(bin_source, items)
    os.mkdir(bin_source2)
    for root, dirs, files in os.walk(current_dir):
        # pass the filename and split for .class extension
        check_tub = str(files)
        suffix_check = os.path.splitext(check_tub)
        # check for bin files
        if "class" in suffix_check[1]:
            # iterate the files list and move to another location
            try:
                for m in files:
                    file_path = os.path.join(root, m)
                    print(file_path)
                    shutil.copy(file_path, bin_source2)
                    # log information to text file
                logging.info(f'{time.asctime()}, .bin files for {items} are placed in {bin_source2}')
            except:
                pass
        else:
            logging.info(f'{time.asctime()}no .classes seen in the project for {items}')
