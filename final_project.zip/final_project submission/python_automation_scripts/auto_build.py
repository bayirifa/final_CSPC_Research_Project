# Benjamin Ayirifa
# Lewis University
# Research project, Fall semester 2023

# import
import os
import logging
# path variable
path_to_build = 'C:/Users/owner/Desktop/project analysis/New folder/'
build_log = 'C:/Users/owner/Desktop/logfile/build.log'
# clean command
mvn_clean = 'mvn clean'
mvn_validate = 'mvn validate'
mvn_compile = 'mvn compile'
# initiate build log
logging.basicConfig(filename=build_log,level=logging.DEBUG)
# builds each project with iterative approach
for items in os.listdir(path_to_build):
    # create the project path and cd into the cloned dir
    building_project = path_to_build + items
    if os.path.isdir(building_project):
        os.chdir(building_project)
        # execute maven terminal commands
        try:
            os.system(mvn_clean)
            os.system(mvn_validate)
            os.system(mvn_compile)
            logging.info(f'{building_project} builds successfully')
            print(f'{building_project} builds successfully')
        # catch all exemptions and print out exemptions
        except (OSError, Exception)as build_error:
            # print(build_error)
            logging.error(f'{building_project} had a problem: {build_error}')
            logging.warning(f'{building_project} has a warning message')
            logging.exception(f'{building_project} has a problem')
            pass
    else:
        logging.info(f'{building_project} is not a directory')
